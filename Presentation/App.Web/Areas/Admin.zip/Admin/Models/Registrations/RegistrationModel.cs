﻿using App.Core.Domain.Registrations;
using App.Web.Infrastructure.Mapper.BaseModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace App.Web.Areas.Admin.Models.Registrations
{
    /// <summary>
    /// Admin ViewModel for FI Registration entity
    /// </summary>
    public record class RegistrationModel : BaseAppEntityModel
    {
        public int Id { get; set; }

        // Institution Snapshot
        [Display(Name = "Institution")]
        public int InstitutionId { get; set; }
        public string InstitutionName { get; set; }

        // License Data
        [Required]
        [Display(Name = "License Number")]
        public string LicenseNumber { get; set; }

        [Display(Name = "License Sector")]
        public int LicenseSectorId { get; set; }
        public string LicenseSectorName { get; set; }

        [Display(Name = "Issue Date")]
        public DateTime? IssueDate { get; set; }

        [Display(Name = "Expiry Date")]
        public DateTime? ExpiryDate { get; set; }

        // Workflow & Status
        [Display(Name = "Registration Status")]
        public RegistrationStatus Status { get; set; }

        [Display(Name = "Approval Status")]
        public ApprovalStatus ApprovalStatus { get; set; }

        [Display(Name = "Validation Status")]
        public ValidationStatus ValidationStatus { get; set; }

        [Display(Name = "Workflow Step")]
        public WorkflowStep CurrentStep { get; set; }

        // System Info
        public DateTime CreatedOnUtc { get; set; }
        public DateTime? UpdatedOnUtc { get; set; }
        public string CreatedByUserName { get; set; }
        public string UpdatedByUserName { get; set; }

        // Linked Data (simplified, can expand later)
        public List<ContactModel> Contacts { get; set; } = new();
        public List<DocumentModel> Documents { get; set; } = new();
        public List<StatusLogModel> StatusLogs { get; set; } = new();
        public string? CountryName { get; set; }
        public bool IsActive { get; set; }
    }
}
