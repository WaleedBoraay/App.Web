﻿namespace App.Web.Areas.Admin.Models.Settings
{
    public class SettingSearchModel
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public IList<SettingModel> Results { get; set; }
    }
}
