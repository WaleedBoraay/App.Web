// import accordian from '.~/Modern/.~/Modern/.~/Modern/main/ui-components/accordian/code-ui-accordian.html'
// Call the function for multiple files
loadAndHighlightHtml(".~/Modern/.~/Modern/.~/Modern/main/ui-components/accordian/code-ui-accordian.html", "output1");
// loadAndHighlightHtml("ui-components/accordian/code-ui-accordian-flush.html", "output2");
