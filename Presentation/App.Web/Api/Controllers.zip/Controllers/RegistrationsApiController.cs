﻿using App.Core;
using App.Core.Domain.Notifications;
using App.Core.Domain.Registrations;
using App.Services;
using App.Services.Audit;
using App.Services.Directory;
using App.Services.Institutions;
using App.Services.Notifications;
using App.Services.Registrations;
using App.Services.Security;
using App.Services.Users;
using App.Web.Areas.Admin.Models.Registrations;
using Microsoft.AspNetCore.Mvc;

namespace App.Web.Api.Admin
{
    [Route("api/admin/registrations")]
    [ApiController]
    public class RegistrationsApiController : ControllerBase
    {
        private readonly IRegistrationService _registrationService;
        private readonly IAuditTrailService _auditService;
        private readonly INotificationService _notificationService;
        private readonly ICountryService _countryService;
        private readonly IUserService _userService;
        private readonly IRoleService _roleService;
        private readonly IWorkContext _workContext;
        private readonly IInstitutionService _institutionService;
        private readonly IDocumentService _documentService;

        public RegistrationsApiController(
            IRegistrationService registrationService,
            IAuditTrailService auditService,
            INotificationService notificationService,
            ICountryService countryService,
            IUserService userService,
            IRoleService roleService,
            IWorkContext workContext,
            IInstitutionService institutionService,
            IDocumentService documentService)
        {
            _registrationService = registrationService;
            _auditService = auditService;
            _notificationService = notificationService;
            _countryService = countryService;
            _userService = userService;
            _roleService = roleService;
            _workContext = workContext;
            _institutionService = institutionService;
            _documentService = documentService;
        }

        // GET: api/admin/registrations
        [HttpGet]
        public async Task<IActionResult> GetAll(int userId)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            var roles = await _roleService.GetRolesByUserIdAsync(userId);

            bool isMaker = roles.Any(r => r.SystemName == "Maker" || r.Name == "Maker");
            bool isChecker = roles.Any(r => r.SystemName == "Checker" || r.Name == "Checker");
            bool isRegulator = roles.Any(r => r.SystemName == "Regulator");
            bool isInspector = roles.Any(r => r.SystemName == "Inspector");

            var allRegs = await _registrationService.GetAllAsync();

            var visibleRegs = allRegs.Where(r =>
                (isMaker && (r.StatusId == (int)RegistrationStatus.Draft || r.StatusId == (int)RegistrationStatus.ReturnedForEdit)) ||
                (isChecker && r.StatusId == (int)RegistrationStatus.Submitted)
            ).ToList();

            var model = visibleRegs.Select(r => new
            {
                r.Id,
                r.InstitutionId,
                r.InstitutionName,
                r.LicenseNumber,
                r.StatusId,
                Status = (RegistrationStatus)r.StatusId,
                CreatedOnUtc = r.CreatedOnUtc ?? DateTime.UtcNow,
                CreatedByUserName = currentUser.Username
            });

            return Ok(model);
        }

        // GET: api/admin/registrations/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var reg = await _registrationService.GetByIdAsync(id);
            if (reg == null) return NotFound();

            var country = await _countryService.GetByIdAsync(reg.CountryId);
            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            var model = new
            {
                reg.Id,
                reg.InstitutionId,
                reg.InstitutionName,
                reg.LicenseNumber,
                reg.LicenseSectorId,
                reg.IssueDate,
                reg.ExpiryDate,
                reg.StatusId,
                CountryName = country?.Name,
                CreatedByUserName = user?.Username,
                IsActive = user?.IsActive ?? false,
                Contacts = (await _registrationService.GetContactsByRegistrationIdAsync(id)),
                Documents = (await _registrationService.GetDocumentsByRegistrationIdAsync(id)),
                StatusLogs = (await _registrationService.GetStatusHistoryAsync(id))
            };

            return Ok(model);
        }

        // POST: api/admin/registrations
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] RegistrationModel model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var currentUser = await _workContext.GetCurrentUserAsync();

            var entity = new Registration
            {
                InstitutionName = model.InstitutionName,
                LicenseNumber = model.LicenseNumber,
                LicenseSectorId = model.LicenseSectorId,
                FinancialDomainId = model.FinancialDomainId,
                IssueDate = model.IssueDate,
                ExpiryDate = model.ExpiryDate,
                CountryId = model.CountryId,
                Address = model.Address,
                CreatedByUserId = currentUser.Id,
                CreatedOnUtc = DateTime.UtcNow,
                Status = RegistrationStatus.Draft,
                StatusId = (int)RegistrationStatus.Draft
            };

            await _registrationService.InsertAsync(entity);
            return Ok(new { success = true, registrationId = entity.Id });
        }

        // PUT: api/admin/registrations/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] RegistrationModel model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var reg = await _registrationService.GetByIdAsync(id);
            if (reg == null) return NotFound();

            reg.InstitutionName = model.InstitutionName;
            reg.LicenseNumber = model.LicenseNumber;
            reg.LicenseSectorId = model.LicenseSectorId;
            reg.FinancialDomainId = model.FinancialDomainId;
            reg.IssueDate = model.IssueDate;
            reg.ExpiryDate = model.ExpiryDate;
            reg.CountryId = model.CountryId;
            reg.Address = model.Address;

            await _registrationService.UpdateAsync(reg);
            await _auditService.LogUpdateAsync("Registration", reg.Id, reg.CreatedByUserId, "Registration edited");

            return Ok(new { success = true });
        }

        // POST: api/admin/registrations/{id}/submit
        [HttpPost("{id}/submit")]
        public async Task<IActionResult> Submit(int id, [FromBody] string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            await HandleStatusChange(id, RegistrationStatus.Submitted, currentUser.Id, remarks);
            return Ok(new { success = true });
        }

        // POST: api/admin/registrations/{id}/validate
        [HttpPost("{id}/validate")]
        public async Task<IActionResult> Validate(int id, [FromBody] string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            var roles = await _roleService.GetRolesByUserIdAsync(currentUser.Id);

            if (roles.Any(r => r.SystemName == "Checker"))
            {
                await HandleStatusChange(id, RegistrationStatus.Approved, currentUser.Id, remarks);
                return Ok(new { success = true });
            }

            return Forbid();
        }

        // POST: api/admin/registrations/{id}/approve
        [HttpPost("{id}/approve")]
        public async Task<IActionResult> Approve(int id)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            await _registrationService.ApproveRegistrationAsync(id, currentUser.Id);

            await _notificationService.SendAsync(
                registrationId: id,
                eventType: NotificationEvent.RegistrationApproved,
                triggeredByUserId: currentUser.Id,
                recipientUserId: currentUser.Id,
                channel: NotificationChannel.InApp,
                tokens: new Dictionary<string, string>
                {
                    ["RegistrationId"] = id.ToString(),
                    ["InstitutionName"] = (await _registrationService.GetByIdAsync(id))?.InstitutionName ?? "",
                    ["Status"] = RegistrationStatus.Approved.ToString(),
                    ["TriggeredBy"] = currentUser.Username
                });

            await _auditService.LogUpdateAsync("Registration", id, currentUser.Id, "Registration approved");

            return Ok(new { success = true });
        }

        // POST: api/admin/registrations/{id}/reject
        [HttpPost("{id}/reject")]
        public async Task<IActionResult> Reject(int id, [FromBody] string comment)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            await _registrationService.RejectRegistrationAsync(id, currentUser.Id, comment);
            return Ok(new { success = true });
        }

        // POST: api/admin/registrations/{id}/return-for-edit
        [HttpPost("{id}/return-for-edit")]
        public async Task<IActionResult> ReturnForEdit(int id, [FromBody] string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();
            await HandleStatusChange(id, RegistrationStatus.ReturnedForEdit, currentUser.Id, remarks);
            return Ok(new { success = true });
        }

        // Helper
        private async Task HandleStatusChange(int regId, RegistrationStatus newStatus, int triggeredByUserId, string remarks)
        {
            var reg = await _registrationService.GetByIdAsync(regId);
            if (reg == null) return;

            reg.StatusId = (int)newStatus;
            reg.Status = newStatus;
            await _registrationService.UpdateAsync(reg);

            await _auditService.LogUpdateAsync("Registration", reg.Id, triggeredByUserId, newValue: newStatus.ToString(),
                comment: remarks ?? $"Status changed to {newStatus}");

            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            if (newStatus == RegistrationStatus.Approved && user != null)
                await _userService.ActivateAsync(user.Id);

            var eventType = MapStatusToEvent(newStatus);

            if (user != null)
            {
                await _notificationService.SendAsync(
                    registrationId: reg.Id,
                    eventType: eventType,
                    triggeredByUserId: triggeredByUserId,
                    recipientUserId: user.Id,
                    channel: NotificationChannel.InApp,
                    tokens: new Dictionary<string, string>
                    {
                        ["RegistrationId"] = reg.Id.ToString(),
                        ["InstitutionName"] = reg.InstitutionName,
                        ["Status"] = newStatus.ToString(),
                        ["TriggeredBy"] = (await _userService.GetByIdAsync(triggeredByUserId)).Username
                    });
            }
        }

        private NotificationEvent MapStatusToEvent(RegistrationStatus status)
        {
            return status switch
            {
                RegistrationStatus.Submitted => NotificationEvent.RegistrationSubmitted,
                RegistrationStatus.Approved => NotificationEvent.RegistrationApproved,
                RegistrationStatus.Rejected => NotificationEvent.RegistrationRejected,
                RegistrationStatus.ReturnedForEdit => NotificationEvent.RegistrationReturnedForEdit,
                RegistrationStatus.FinalSubmission => NotificationEvent.RegistrationFinalSubmission,
                RegistrationStatus.Archived => NotificationEvent.RegistrationArchived,
                _ => NotificationEvent.InstitutionCreated
            };
        }
    }
}
