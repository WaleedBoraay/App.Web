﻿namespace App.Web.Areas.Admin.Models.Security
{
    public class AssignRoleToUserModel
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
    }
}
