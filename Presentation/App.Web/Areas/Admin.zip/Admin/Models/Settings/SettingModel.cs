﻿namespace App.Web.Areas.Admin.Models.Settings
{
    public class SettingModel
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }

}
