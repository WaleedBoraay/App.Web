﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Core.Domain.Notifications
{
    public enum NotificationType
    {
        Success,
        Error,
        Warning,
        Info
    }
}
