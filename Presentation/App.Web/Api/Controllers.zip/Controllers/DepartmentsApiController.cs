﻿using App.Core.Domain.Organization;
using App.Services.Organization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace App.Web.Api.Admin
{
    [Route("api/admin/departments")]
    [ApiController]
    public class DepartmentsApiController : ControllerBase
    {
        private readonly IOrganizationsServices _organizationsServices;

        public DepartmentsApiController(IOrganizationsServices organizationsServices)
        {
            _organizationsServices = organizationsServices;
        }

        // GET: api/admin/departments
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var departments = await _organizationsServices.GetAllDepartmentsAsync();
            return Ok(departments);
        }

        // GET: api/admin/departments/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var dept = await _organizationsServices.GetDepartmentByIdAsync(id);
            if (dept == null) return NotFound();
            return Ok(dept);
        }

        // POST: api/admin/departments
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Department model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            await _organizationsServices.CreateDepartmentAsync(model);
            return Ok(new { success = true, message = "Department created successfully" });
        }

        // PUT: api/admin/departments/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Department model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var dept = await _organizationsServices.GetDepartmentByIdAsync(id);
            if (dept == null) return NotFound();

            model.Id = id; // Ensure the id is set correctly
            await _organizationsServices.UpdateDepartmentAsync(model);

            return Ok(new { success = true, message = "Department updated successfully" });
        }

        // DELETE: api/admin/departments/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var dept = await _organizationsServices.GetDepartmentByIdAsync(id);
            if (dept == null) return NotFound();

            await _organizationsServices.DeleteDepartmentAsync(dept);
            return Ok(new { success = true, message = "Department deleted successfully" });
        }
    }
}
