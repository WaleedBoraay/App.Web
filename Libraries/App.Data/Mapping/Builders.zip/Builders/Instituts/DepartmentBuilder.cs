using FluentMigrator.Builders.Create.Table;
using App.Core.Builders;
using App.Core.Domain.Institutions;

namespace App.Data.Mapping.Builders.Institutions
{
    /// <summary>
    /// Represents the Department entity builder
    /// </summary>
    public partial class DepartmentBuilder : EntityBuilder<Department>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(Department.Id)).AsInt32().PrimaryKey().Identity()
                .WithColumn(nameof(Department.Name)).AsString(128).NotNullable()
                .WithColumn(nameof(Department.InstitutionId)).AsInt32().NotNullable()
                .WithColumn(nameof(Department.IsActive)).AsBoolean().NotNullable()
                .WithColumn(nameof(Department.CreatedOnUtc)).AsDateTime2().NotNullable()
                .WithColumn(nameof(Department.UpdatedOnUtc)).AsDateTime2().Nullable();
        }
    }
}