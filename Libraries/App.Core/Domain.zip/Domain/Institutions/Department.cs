using System;
using App.Core;

namespace App.Core.Domain.Institutions
{
    public class Department : BaseEntity
    {
        public string Name { get; set; }
        public int InstitutionId { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOnUtc { get; set; }
        public DateTime? UpdatedOnUtc { get; set; }
    }
}
