using App.Services.Localization;
using App.Services.Settings;
using App.Services.Users;
using App.Web.Areas.Admin.Models;
using App.Web.Areas.Admin.Models.Settings;
using App.Web.Areas.Admin.Models.Users;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace App.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class SettingsController : Controller
    {
        private readonly IUserSettingsService _userSettings;
        private readonly ISettingService _settingService;
        private readonly ILanguageService _languageService;
        public SettingsController(IUserSettingsService userSettings,
            ISettingService settingService,
            ILanguageService languageService
            )
        {
            _userSettings = userSettings;
            _settingService = settingService;
            _languageService = languageService;
        }

        [HttpGet]
        public async Task<IActionResult> AllSettings(string name, string value)
        {
            var getall = await _settingService.GetAllAsync();
            var settings = await _settingService.GetAsync(name, value);
            var model = new SettingSearchModel
            {
                Name = name,
                Value = value,
                Results = settings.Select(s => new SettingModel
                {
                    Name = name,
                    Value = s.ToString()
                }).ToList()
            };
            return View(getall);
        }

        [HttpPost]
        public async Task<IActionResult> EditSetting(string name, string value)
        {
            await _settingService.SetAsync(name, value);
            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteSetting(string name)
        {
            await _settingService.DeleteAsync(name);
            return Json(new { success = true });
        }

        [HttpGet]
        public async Task<IActionResult> UserPreferences(int userId)
        {
            Core.Domain.Users.UserPreference? pref = await _userSettings.GetByUserIdAsync(userId);
            if (pref == null)
            {
                // default model if user has no preferences yet
                return View(new UserPreferenceModel { UserId = userId });
            }

            var model = new UserPreferenceModel
            {
                UserId = userId,
                LanguageId = pref.LanguageId,
                EnableMfa = pref.EnableMfa,
                NotifyByEmail = pref.NotifyByEmail,
                NotifyBySms = pref.NotifyBySms,
                NotifyInApp = pref.NotifyInApp
            };

            // Populate languages for dropdown
            ViewBag.Languages = await _languageService.GetAllAsync();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UserPreferences(UserPreferenceModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Languages = await _languageService.GetAllAsync();
                return View(model);
            }

            // Update preferences
            await _userSettings.SetLanguageAsync(model.UserId, model.LanguageId ?? 1);
            await _userSettings.ToggleMfaAsync(model.UserId, model.EnableMfa);
            await _userSettings.UpdateNotificationPreferencesAsync(
                model.UserId,
                model.NotifyByEmail,
                model.NotifyBySms,
                model.NotifyInApp
            );

            ViewData["SuccessMessage"] = "User preferences updated successfully";

            ViewBag.Languages = await _languageService.GetAllAsync();
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> System()
        {
            var model = new SystemSettingsModel
            {
                ApplicationName = await _settingService.GetAsync("System.ApplicationName", "Supervision"),
                DefaultTimeZone = await _settingService.GetAsync("System.DefaultTimeZone", "UTC"),
                EnableEmail = await _settingService.GetAsync("System.EnableEmail", true),
                EnableAuditTrail = await _settingService.GetAsync("System.EnableAuditTrail", false)
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> System(SystemSettingsModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            await _settingService.SetAsync("System.ApplicationName", model.ApplicationName);
            await _settingService.SetAsync("System.DefaultTimeZone", model.DefaultTimeZone);
            await _settingService.SetAsync("System.EnableEmail", model.EnableEmail);
            await _settingService.SetAsync("System.EnableAuditTrail", model.EnableAuditTrail);

            ViewData["SuccessMessage"] = "System settings updated successfully";
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Notifications()
        {
            var model = new NotificationSettingsModel
            {
                EnableEmail = await _settingService.GetAsync("Notifications.EnableEmail", true),
                EnableSms = await _settingService.GetAsync("Notifications.EnableSms", false),
                EnableInApp = await _settingService.GetAsync("Notifications.EnableInApp", true)
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Notifications(NotificationSettingsModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            await _settingService.SetAsync("Notifications.EnableEmail", model.EnableEmail);
            await _settingService.SetAsync("Notifications.EnableSms", model.EnableSms);
            await _settingService.SetAsync("Notifications.EnableInApp", model.EnableInApp);

            ViewData["SuccessMessage"] = "Notification settings updated successfully";
            return View(model);
        }
    }
}
