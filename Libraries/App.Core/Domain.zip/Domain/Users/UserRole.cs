using App.Core.Domain.Security;
using System;

namespace App.Core.Domain.Users
{
    /// <summary>
    /// Many-to-many mapping between users and roles.
    /// </summary>
    public class UserRole : BaseEntity
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }

        public virtual Role Role { get; set; }
        public virtual AppUser User { get; set; }
    }
}
