using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using App.Core.Domain.Users;
using App.Web.Areas.Admin.Models;
using App.Services.Security;
using App.Core.RepositoryServices;

namespace App.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class UsersController(
        IRepository<AppUser> userRepo,
        IRepository<UserRole> userRoleRepo,
        IEncryptionService encryption
    ) : Controller
    {
        private readonly IRepository<AppUser> _userRepo = userRepo;
        private readonly IRepository<UserRole> _userRoleRepo = userRoleRepo;
        private readonly IEncryptionService _encryption = encryption;

        [HttpGet]
        public IActionResult Create() => View(new CreateUserModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateUserModel model)
        {
            if (!ModelState.IsValid) return View(model);

            if (_userRepo.Table.Any(u => u.Email == model.Email))
            {
                ModelState.AddModelError(nameof(model.Email), "Email already exists");
                return View(model);
            }

            var user = new AppUser
            {
                Email = model.Email,
                Username = model.Username,
                IsActive = model.Active,
                CreatedOnUtc = DateTime.UtcNow,
                PasswordHash = _encryption.CreatePasswordHash(model.Password, string.Empty, PasswordFormat.Hashed),
                PasswordFormatId = (int)PasswordFormat.Hashed
            };
            await _userRepo.InsertAsync(user);

            if (model.RoleIds?.Count > 0)
            {
                foreach (var rid in model.RoleIds.Distinct())
                    await _userRoleRepo.InsertAsync(new UserRole { UserId = user.Id, RoleId = rid });
            }

            TempData["Success"] = "User created";
            return RedirectToAction("Index");
        }
    }
}
