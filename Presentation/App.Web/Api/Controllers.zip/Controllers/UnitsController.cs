﻿using App.Core.Domain.Organization;
using App.Services.Organization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace App.Web.Api.Admin
{
    [ApiController]
    [Route("api/admin/[controller]")]
    public class UnitsController : ControllerBase
    {
        private readonly IOrganizationsServices _organizationsServices;

        public UnitsController(IOrganizationsServices organizationsServices)
        {
            _organizationsServices = organizationsServices;
        }

        [HttpGet("department/{departmentId:int}")]
        public async Task<IActionResult> GetByDepartment(int departmentId)
        {
            var units = await _organizationsServices.GetUnitsByDepartmentIdAsync(departmentId);
            return Ok(units);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var unit = await _organizationsServices.GetUnitByIdAsync(id);
            if (unit == null)
                return NotFound(new { message = "Unit not found" });

            return Ok(unit);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Unit model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _organizationsServices.CreateUnitAsync(model);
            return CreatedAtAction(nameof(GetById), new { id = model.Id }, model);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] Unit model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var existing = await _organizationsServices.GetUnitByIdAsync(id);
            if (existing == null)
                return NotFound(new { message = "Unit not found" });

            existing.Name = model.Name;
            existing.DepartmentId = model.DepartmentId;
            await _organizationsServices.UpdateUnitAsync(existing);
            return Ok(existing);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var unit = await _organizationsServices.GetUnitByIdAsync(id);
            if (unit == null)
                return NotFound(new { message = "Unit not found" });

            await _organizationsServices.DeleteUnitAsync(unit);
            return NoContent();
        }
    }
}
