﻿using Microsoft.AspNetCore.SignalR;

namespace App.Services.Hubs
{
    public class NotificationHub : Hub
    {
    }
}
