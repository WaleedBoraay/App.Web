﻿using App.Core;
using App.Core.Domain.Notifications;
using App.Core.Domain.Registrations;
using App.Services;
using App.Services.Audit;
using App.Services.Directory;
using App.Services.Notifications;
using App.Services.Registrations;
using App.Services.Users;
using App.Web.Areas.Admin.Models.Registrations;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace App.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class RegistrationsController : Controller
    {
        private readonly IRegistrationService _registrationService;
        private readonly IAuditTrailService _auditService;
        private readonly INotificationService _notificationService;
        private readonly ICountryService _countryService;
        private readonly IUserService _userService;
        private readonly IWorkContext _workContext;

        public RegistrationsController(
            IRegistrationService registrationService,
            IAuditTrailService auditService,
            INotificationService notificationService,
            ICountryService countryService,
            IUserService userService,
            IWorkContext workContext)
        {
            _registrationService = registrationService;
            _auditService = auditService;
            _notificationService = notificationService;
            _countryService = countryService;
            _userService = userService;
            _workContext = workContext;
        }

        // GET: /Admin/Registrations
        public async Task<IActionResult> Index()
        {
            var regs = await _registrationService.GetAllAsync();

            var model = regs.Select(r => new RegistrationModel
            {
                Id = r.Id,
                InstitutionId = r.InstitutionId,
                InstitutionName = r.InstitutionName,
                LicenseNumber = r.LicenseNumber,
                LicenseSectorId = r.LicenseSectorId,
                IssueDate = r.IssueDate,
                ExpiryDate = r.ExpiryDate,
                Status = r.Status,
            }).ToList();

            return View(model);
        }

        // GET: /Admin/Registrations/Create
        public IActionResult Create() => View(new RegistrationModel());

        // POST: /Admin/Registrations/Create
        [HttpPost]
        public async Task<IActionResult> Create(RegistrationModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var entity = new Registration
            {
                InstitutionId = model.InstitutionId,
                InstitutionName = model.InstitutionName,
                LicenseNumber = model.LicenseNumber,
                LicenseSectorId = model.LicenseSectorId,
                IssueDate = model.IssueDate,
                ExpiryDate = model.ExpiryDate,
                Status = model.Status,
                CreatedOnUtc = System.DateTime.UtcNow,
                CreatedByUserId = (await _workContext.GetCurrentUserAsync()).Id
            };

            var reg = await _registrationService.InsertAsync(entity);
            var currentUser = await _workContext.GetCurrentUserAsync();

            await _auditService.LogCreateAsync("Registration", reg.Id, currentUser.Id);

            return RedirectToAction(nameof(Details), new { id = reg.Id });
        }

        // GET: /Admin/Registrations/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var reg = await _registrationService.GetByIdAsync(id);
            if (reg == null) return NotFound();

            var model = new RegistrationModel
            {
                Id = reg.Id,
                InstitutionId = reg.InstitutionId,
                InstitutionName = reg.InstitutionName,
                LicenseNumber = reg.LicenseNumber,
                LicenseSectorId = reg.LicenseSectorId,
                IssueDate = reg.IssueDate,
                ExpiryDate = reg.ExpiryDate,
                Status = reg.Status,
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(RegistrationModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var reg = await _registrationService.GetByIdAsync(model.Id);
            if (reg == null) return NotFound();

            reg.InstitutionId = model.InstitutionId;
            reg.InstitutionName = model.InstitutionName;
            reg.LicenseNumber = model.LicenseNumber;
            reg.LicenseSectorId = model.LicenseSectorId;
            reg.IssueDate = model.IssueDate;
            reg.ExpiryDate = model.ExpiryDate;
            reg.Status = model.Status;

            await _registrationService.UpdateAsync(reg);

            var currentUser = await _workContext.GetCurrentUserAsync();
            await _auditService.LogUpdateAsync("Registration", model.Id, currentUser.Id, comment: "Edited");

            return RedirectToAction(nameof(Details), new { id = model.Id });
        }

        // GET: /Admin/Registrations/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var reg = await _registrationService.GetByIdAsync(id);
            if (reg == null) return NotFound();

            var country = await _countryService.GetByIdAsync(reg.CountryId);
            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            var model = new RegistrationModel
            {
                Id = reg.Id,
                InstitutionId = reg.InstitutionId,
                InstitutionName = reg.InstitutionName,
                LicenseNumber = reg.LicenseNumber,
                LicenseSectorId = reg.LicenseSectorId,
                IssueDate = reg.IssueDate,
                ExpiryDate = reg.ExpiryDate,
                Status = reg.Status,
                CountryName = country?.Name,
                CreatedByUserName = user?.Username,
                IsActive = user?.IsActive ?? false,
                Contacts = (await _registrationService.GetContactsByRegistrationIdAsync(id))
                    .Select(c => new ContactModel
                    {
                        Id = c.Id,
                        RegistrationId = c.RegistrationId,
                        ContactTypeId = c.ContactTypeId,
                        JobTitle = c.JobTitle,
                        FirstName = c.FirstName,
                        MiddleName = c.MiddleName,
                        LastName = c.LastName,
                        ContactPhone = c.ContactPhone,
                        BusinessPhone = c.BusinessPhone,
                        Email = c.Email,
                        NationalityCountryId = c.NationalityCountryId,
                        CreatedOnUtc = c.CreatedOnUtc,
                        UpdatedOnUtc = c.UpdatedOnUtc
                    }).ToList(),
                Documents = (await _registrationService.GetDocumentsByRegistrationIdAsync(id))
                    .Select(d => new DocumentModel
                    {
                        Id = d.Id,
                        DocumentType = d.DocumentType,
                        FilePath = d.FilePath,
                        UploadedOnUtc = d.UploadedOnUtc
                    }).ToList(),
                StatusLogs = (await _registrationService.GetStatusHistoryAsync(id))
                    .Select(h => new StatusLogModel
                    {
                        Id = h.Id,
                        RegistrationId = h.RegistrationId,
                        RegistrationStatus = h.RegistrationStatus,
                        ValidationStatus = h.ValidationStatus,
                        ApprovalStatus = h.ApprovalStatus,
                        AuditStatus = h.AuditStatus,
                        PerformedBy = h.PerformedBy,
                        ActionDateUtc = h.ActionDateUtc,
                        Remarks = h.Remarks
                    }).ToList()
            };

            return View(model);
        }

        // Workflow Actions
        [HttpPost]
        public async Task<IActionResult> Submit(int id, string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();

            await _registrationService.SubmitAsync(id, currentUser.Id, remarks);
            await _auditService.LogUpdateAsync("Registration", id, currentUser.Id, comment: "Submitted");

            await _registrationService.NotifyAsync(
                id,
                NotificationEvent.RegistrationSubmitted,
                currentUser.Id,
                recipientUserId: 0
            );

            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        public async Task<IActionResult> Approve(int id, string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();

            await _registrationService.ApproveAsync(id, currentUser.Id, ApprovalStatus.Approved, remarks);

            var reg = await _registrationService.GetByIdAsync(id);
            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            if (user != null)
            {
                await _userService.ActivateAsync(user.Id);
                await _registrationService.NotifyAsync(
                    id,
                    NotificationEvent.RegistrationApproved,
                    currentUser.Id,
                    user.Id
                );
            }

            await _auditService.LogUpdateAsync("Registration", id, currentUser.Id, comment: "Approved");

            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        public async Task<IActionResult> Reject(int id, string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();

            await _registrationService.RejectAsync(id, currentUser.Id, remarks);

            var reg = await _registrationService.GetByIdAsync(id);
            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            if (user != null)
            {
                await _registrationService.NotifyAsync(
                    id,
                    NotificationEvent.RegistrationRejected,
                    currentUser.Id,
                    user.Id
                );
            }

            await _auditService.LogUpdateAsync("Registration", id, currentUser.Id, comment: "Rejected");

            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        public async Task<IActionResult> ReturnForEdit(int id, string remarks)
        {
            var currentUser = await _workContext.GetCurrentUserAsync();

            await _registrationService.ReturnForEditAsync(id, currentUser.Id, remarks);

            var reg = await _registrationService.GetByIdAsync(id);
            var user = await _userService.GetByIdAsync(reg.CreatedByUserId);

            if (user != null)
            {
                await _registrationService.NotifyAsync(
                    id,
                    NotificationEvent.RegistrationReturnedForEdit,
                    currentUser.Id,
                    user.Id
                );
            }

            await _auditService.LogUpdateAsync("Registration", id, currentUser.Id, comment: "Returned for edit");

            return RedirectToAction(nameof(Details), new { id });
        }
    }
}
