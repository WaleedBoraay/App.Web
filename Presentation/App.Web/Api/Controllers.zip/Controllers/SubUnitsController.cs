﻿using App.Core.Domain.Organization;
using App.Services.Organization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace App.Web.Api.Admin
{
    [ApiController]
    [Route("api/admin/[controller]")]
    public class SubUnitsController : ControllerBase
    {
        private readonly IOrganizationsServices _organizationsServices;

        public SubUnitsController(IOrganizationsServices organizationsServices)
        {
            _organizationsServices = organizationsServices;
        }

        [HttpGet("unit/{unitId:int}")]
        public async Task<IActionResult> GetByUnit(int unitId)
        {
            var subUnits = await _organizationsServices.GetSubUnitsByUnitIdAsync(unitId);
            return Ok(subUnits);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var subUnit = await _organizationsServices.GetSubUnitByIdAsync(id);
            if (subUnit == null)
                return NotFound(new { message = "SubUnit not found" });

            return Ok(subUnit);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] SubUnit model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _organizationsServices.CreateSubUnitAsync(model);
            return CreatedAtAction(nameof(GetById), new { id = model.Id }, model);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] SubUnit model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var existing = await _organizationsServices.GetSubUnitByIdAsync(id);
            if (existing == null)
                return NotFound(new { message = "SubUnit not found" });

            existing.Name = model.Name;
            existing.UnitId = model.UnitId;
            await _organizationsServices.UpdateSubUnitAsync(existing);
            return Ok(existing);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var subUnit = await _organizationsServices.GetSubUnitByIdAsync(id);
            if (subUnit == null)
                return NotFound(new { message = "SubUnit not found" });

            await _organizationsServices.DeleteSubUnitAsync(subUnit);
            return NoContent();
        }
    }
}
