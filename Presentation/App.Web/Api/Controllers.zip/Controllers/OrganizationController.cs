﻿using App.Core.Domain.Organization;
using App.Services.Organization;
using App.Services.Security;
using App.Services.Users;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace App.Web.Api.Admin
{
    [ApiController]
    [Route("api/admin/[controller]")]
    public class OrganizationController : ControllerBase
    {
        private readonly IOrganizationsServices _orgService;
        private readonly IUserService _userService;
        private readonly IRoleService _roleService;

        public OrganizationController(
            IOrganizationsServices orgService,
            IUserService userService,
            IRoleService roleService)
        {
            _orgService = orgService;
            _userService = userService;
            _roleService = roleService;
        }

        [HttpGet("structure")]
        public async Task<IActionResult> GetOrganizationStructure()
        {
            var departments = await _orgService.GetAllDepartmentsWithUsersAsync();
            var units = await _orgService.GetAllUnitsAsync();
            var subUnits = await _orgService.GetAllSubUnitsAsync();
            var allUsers = await _userService.GetAllAsync();
            var allRoles = await _roleService.GetAllAsync();

            var model = departments.Select(d => new
            {
                DepartmentId = d.Id,
                DepartmentName = d.Name,
                Units = units
                    .Where(u => u.DepartmentId == d.Id)
                    .Select(u => new
                    {
                        UnitId = u.Id,
                        UnitName = u.Name,
                        SubUnits = subUnits
                            .Where(su => su.UnitId == u.Id)
                            .Select(su => new
                            {
                                SubUnitId = su.Id,
                                SubUnitName = su.Name,
                                Users = allUsers
                                    .Where(x => x.SubUnitId == su.Id)
                                    .Select(x => new
                                    {
                                        x.Id,
                                        x.Username,
                                        x.Email,
                                        Roles = _roleService.GetRolesByUserIdAsync(x.Id).Result
                                            .Select(r => new { r.Id, r.Name })
                                            .ToList()
                                    })
                            })
                    })
            });

            return Ok(new
            {
                Departments = model,
                AllUsers = allUsers.Select(u => new { u.Id, u.Username, u.Email }),
                AllRoles = allRoles.Select(r => new { r.Id, r.Name })
            });
        }

        // ✅ Department endpoints
        [HttpPost("department")]
        public async Task<IActionResult> CreateDepartment([FromBody] Department model)
        {
            if (string.IsNullOrWhiteSpace(model.Name))
                return BadRequest(new { message = "Department name is required." });

            await _orgService.CreateDepartmentAsync(model);
            return CreatedAtAction(nameof(GetOrganizationStructure), new { id = model.Id }, model);
        }

        [HttpDelete("department/{id:int}")]
        public async Task<IActionResult> DeleteDepartment(int id)
        {
            var dept = await _orgService.GetDepartmentByIdAsync(id);
            if (dept == null)
                return NotFound(new { message = "Department not found" });

            await _orgService.DeleteDepartmentAsync(dept);
            return NoContent();
        }

        // ✅ Unit endpoints
        [HttpPost("unit")]
        public async Task<IActionResult> CreateUnit([FromBody] Unit model)
        {
            if (string.IsNullOrWhiteSpace(model.Name))
                return BadRequest(new { message = "Unit name is required." });

            await _orgService.CreateUnitAsync(model);
            return CreatedAtAction(nameof(GetOrganizationStructure), new { id = model.Id }, model);
        }

        [HttpDelete("unit/{id:int}")]
        public async Task<IActionResult> DeleteUnit(int id)
        {
            var unit = await _orgService.GetUnitByIdAsync(id);
            if (unit == null)
                return NotFound(new { message = "Unit not found" });

            await _orgService.DeleteUnitAsync(unit);
            return NoContent();
        }

        // ✅ SubUnit endpoints
        [HttpPost("subunit")]
        public async Task<IActionResult> CreateSubUnit([FromBody] SubUnit model)
        {
            if (string.IsNullOrWhiteSpace(model.Name))
                return BadRequest(new { message = "SubUnit name is required." });

            await _orgService.CreateSubUnitAsync(model);
            return CreatedAtAction(nameof(GetOrganizationStructure), new { id = model.Id }, model);
        }

        [HttpDelete("subunit/{id:int}")]
        public async Task<IActionResult> DeleteSubUnit(int id)
        {
            var subUnit = await _orgService.GetSubUnitByIdAsync(id);
            if (subUnit == null)
                return NotFound(new { message = "SubUnit not found" });

            await _orgService.DeleteSubUnitAsync(subUnit);
            return NoContent();
        }

        // ✅ User assignment to org units
        [HttpPost("assign-user")]
        public async Task<IActionResult> AssignUser([FromBody] AssignUserModel model)
        {
            var user = await _userService.GetByIdAsync(model.UserId);
            if (user == null)
                return NotFound(new { message = "User not found" });

            user.DepartmentId = model.DepartmentId;
            user.UnitId = model.UnitId;
            user.SubUnitId = model.SubUnitId;
            await _userService.UpdateAsync(user);

            if (model.RoleId.HasValue)
                await _roleService.AddUserToRoleAsync(model.UserId, model.RoleId.Value);

            return Ok(new { message = "User assigned successfully." });
        }

        [HttpPost("remove-user-role")]
        public async Task<IActionResult> RemoveUserRole([FromBody] RemoveUserRoleModel model)
        {
            await _roleService.RemoveUserFromRoleAsync(model.UserId, model.RoleId);
            return Ok(new { message = "Role removed from user." });
        }
    }

    public class AssignUserModel
    {
        public int UserId { get; set; }
        public int? RoleId { get; set; }
        public int? DepartmentId { get; set; }
        public int? UnitId { get; set; }
        public int? SubUnitId { get; set; }
    }

    public class RemoveUserRoleModel
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
    }
}
